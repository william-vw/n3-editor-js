#!/bin/bash
websocketd --port 8080 swipl -x /opt/eye/lib/eye.pvm -- --source -
